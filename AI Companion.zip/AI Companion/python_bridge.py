import requests

# Where Ollama is listening on your own PC. Nothing leaves this machine.
OLLAMA_URL = "http://localhost:11434/api/chat"
MODEL = "llama3.2:3b"

# --- NEW: load the personality from a text file ---
# This reads personality.txt (must be in the same folder) and uses it
# as the model's "system" instruction - its character and rules.
with open("personality.txt", "r", encoding="utf-8") as f:
    personality = f.read()

# The conversation starts with the system message at the very front.
# Everything the model says is shaped by this.
messages = [
    {"role": "system", "content": personality}
]

print("Talking to your local AI. Type 'quit' to exit.\n")

while True:
    user_text = input("You: ")
    if user_text.lower() in ("quit", "exit", "bye"):
        print("Bye!")
        break

    messages.append({"role": "user", "content": user_text})

    response = requests.post(OLLAMA_URL, json={
        "model": MODEL,
        "messages": messages,
        "stream": False
    })

    reply = response.json()["message"]["content"]
    messages.append({"role": "assistant", "content": reply})

    print("AI:", reply, "\n")
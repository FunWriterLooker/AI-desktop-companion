import requests
import re
import random
from pathlib import Path
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QTextEdit, QLineEdit, QLabel, QPushButton,
    QMenu, QSystemTrayIcon
)
from PySide6.QtCore import QThread, Signal, Qt, QTimer
from PySide6.QtGui import QPixmap, QIcon, QAction

from watchdog import HardwareWatchdog, describe_usage, describe_gpu_temp

# --- Config ---
OLLAMA_URL = "http://localhost:11434/api/chat"
OLLAMA_TAGS_URL = "http://localhost:11434/api/tags"  # lists installed models
MODEL = "llama3.2:3b"   # default/starting model
MOODS_DIR = Path("moods")
VALID_MOODS = ["happy", "sad", "worried", "neutral"]


def list_installed_models():
    # Ask Ollama what models are installed on this PC. Returns a list of
    # model names (e.g. ["llama3.2:3b", "mistral:latest"]). Empty list if
    # Ollama isn't reachable, so the UI can degrade gracefully.
    try:
        response = requests.get(OLLAMA_TAGS_URL, timeout=5)
        data = response.json()
        return sorted(m["name"] for m in data.get("models", []))
    except Exception:
        return []

# Auto-shrink after this many minutes of no activity. Set to 0 to disable.
# (Later this becomes a user setting in the menu.)
IDLE_MINUTES = 5

# Folder holding personality .txt files. Each file is just CHARACTER text —
# the mood-tag rules below get appended automatically, so personality authors
# never have to think about the technical mood machinery.
PERSONALITIES_DIR = Path("personalities")

# The mood-tag rules, defined ONCE and auto-added to every personality.
MOOD_RULES = """

CRITICAL OUTPUT RULE — THIS OVERRIDES YOUR PERSONALITY:
Your reply must ALWAYS end with a mood tag, written EXACTLY like this,
including the square brackets, on its very own line at the very end:

[mood: happy]

The word inside MUST be exactly one of these four — no others, ever:
happy, sad, worried, neutral
If your mood doesn't perfectly match one, pick the CLOSEST one.
Never write the mood as a plain word in your sentences. Never forget the brackets.
"""


def load_personality(name):
    # Read a personality file and append the mood rules automatically.
    path = PERSONALITIES_DIR / name
    with open(path, "r", encoding="utf-8") as f:
        character = f.read()
    return character + MOOD_RULES


def list_personalities():
    # All .txt files in the personalities folder, sorted.
    if not PERSONALITIES_DIR.is_dir():
        return []
    return sorted(p.name for p in PERSONALITIES_DIR.iterdir()
                  if p.suffix.lower() == ".txt")


# Load a default personality at startup (first one found, or fall back).
_available = list_personalities()
DEFAULT_PERSONALITY = _available[0] if _available else None
personality = load_personality(DEFAULT_PERSONALITY) if DEFAULT_PERSONALITY else "You are Bob, a helpful desktop companion." + MOOD_RULES


# If Bob picks a mood outside our four, map it to the closest valid one.
MOOD_SYNONYMS = {
    "eager": "happy", "excited": "happy", "playful": "happy",
    "joyful": "happy", "cheerful": "happy", "content": "happy",
    "glad": "happy", "pleased": "happy",
    "anxious": "worried", "nervous": "worried", "concerned": "worried",
    "unsure": "worried", "scared": "worried", "afraid": "worried",
    "down": "sad", "unhappy": "sad", "upset": "sad", "depressed": "sad",
    "calm": "neutral", "okay": "neutral", "fine": "neutral",
}


def parse_mood(reply):
    match = re.search(r"\[mood:\s*(\w+)\]", reply, re.IGNORECASE)
    mood = "neutral"
    if match:
        found = match.group(1).lower()
        if found in VALID_MOODS:
            mood = found
        elif found in MOOD_SYNONYMS:
            mood = MOOD_SYNONYMS[found]
    clean = re.sub(r"\[mood:\s*\w+\]", "", reply, flags=re.IGNORECASE).strip()
    return clean, mood


def pick_mood_image(mood):
    folder = MOODS_DIR / mood
    if not folder.is_dir():
        return None
    images = [p for p in folder.iterdir()
              if p.suffix.lower() in (".png", ".jpg", ".jpeg", ".gif", ".webp")]
    if not images:
        return None
    return str(random.choice(images))


class OllamaWorker(QThread):
    reply_ready = Signal(str)

    def __init__(self, messages, model):
        super().__init__()
        self.messages = messages
        self.model = model

    def run(self):
        try:
            response = requests.post(OLLAMA_URL, json={
                "model": self.model,
                "messages": self.messages,
                "stream": False
            })
            data = response.json()
            # If Ollama returns an error object, surface it readably.
            if "error" in data:
                reply = f"[Ollama error: {data['error']}] [mood: worried]"
            else:
                reply = data["message"]["content"]
        except Exception as e:
            reply = f"[Error talking to Ollama: {e}] [mood: worried]"
        self.reply_ready.emit(reply)


class ModelListWorker(QThread):
    # Fetches the installed-model list off the main thread so opening the
    # menu never freezes the UI. Emits the list when done; the window caches it.
    models_ready = Signal(list)

    def run(self):
        self.models_ready.emit(list_installed_models())


# Shared styling for the floating dark panels.
PANEL_STYLE = """
    background-color: rgba(30, 30, 30, 220);
    color: white;
    border-radius: 12px;
    padding: 10px;
"""


class CompanionWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Bob")
        self.resize(460, 360)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self._drag_offset = None
        self.full_chat_mode = False  # start in bubble mode
        self.is_shrunk = False       # start expanded
        self.always_on_top = True    # start pinned on top
        self.current_personality = DEFAULT_PERSONALITY
        self.current_model = MODEL
        self.cached_models = []          # filled in by the background fetch
        self.messages = [{"role": "system", "content": personality}]

        # Outer vertical layout: [top row] / [input row]
        outer = QVBoxLayout(self)

        # --- Top bar: menu + toggle (left) + shrink + close (right) ---
        top_bar = QHBoxLayout()

        # NEW: hamburger (☰) settings menu button.
        self.menu_btn = QPushButton("☰")
        self.menu_btn.setFixedSize(30, 30)
        self.menu_btn.setStyleSheet(PANEL_STYLE)
        self.menu_btn.clicked.connect(self.open_menu)
        top_bar.addWidget(self.menu_btn)

        self.toggle_btn = QPushButton("Full chat")
        self.toggle_btn.setMinimumHeight(30)   # taller so text isn't clipped
        self.toggle_btn.setMinimumWidth(90)
        self.toggle_btn.setStyleSheet(PANEL_STYLE)
        self.toggle_btn.clicked.connect(self.toggle_mode)
        top_bar.addWidget(self.toggle_btn)
        top_bar.addStretch()

        # NEW: shrink button — collapses Bob down to just his face.
        self.shrink_btn = QPushButton("—")
        self.shrink_btn.setFixedSize(30, 30)
        self.shrink_btn.setStyleSheet(PANEL_STYLE)
        self.shrink_btn.clicked.connect(self.shrink)
        top_bar.addWidget(self.shrink_btn)

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(30, 30)
        close_btn.setStyleSheet(PANEL_STYLE)
        close_btn.clicked.connect(self.close)
        top_bar.addWidget(close_btn)
        self.top_bar_widgets = [self.menu_btn, self.toggle_btn,
                                self.shrink_btn, close_btn]
        outer.addLayout(top_bar)

        # --- Middle row: [ bubble / chat ]  on the left,  [ Bob ] on the right ---
        middle = QHBoxLayout()

        # The speech bubble: shows Bob's LATEST reply only. Grows with text.
        self.bubble = QLabel("Hi! I'm Bob.")
        self.bubble.setWordWrap(True)
        self.bubble.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.bubble.setStyleSheet(PANEL_STYLE)
        self.bubble.setMinimumWidth(240)
        middle.addWidget(self.bubble, stretch=1)

        # The full chat log: same as before, hidden until toggled on.
        self.chat_area = QTextEdit()
        self.chat_area.setReadOnly(True)
        self.chat_area.setStyleSheet(PANEL_STYLE)
        self.chat_area.setMinimumWidth(240)
        self.chat_area.hide()  # bubble mode is default
        middle.addWidget(self.chat_area, stretch=1)

        # Bob himself, on the right (like the sketch).
        self.mood_label = QLabel()
        self.mood_label.setAlignment(Qt.AlignCenter)
        self.mood_label.setFixedSize(150, 150)
        middle.addWidget(self.mood_label, stretch=0)
        self.set_mood_image("neutral")

        outer.addLayout(middle)

        # --- Status line (thinking...) ---
        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: #cccccc; font-style: italic; padding-left: 6px;")
        outer.addWidget(self.status_label)

        # --- Input row ---
        self.input_box = QLineEdit()
        self.input_box.setPlaceholderText(f"Talk to {self.display_name()}...")
        self.input_box.setStyleSheet(PANEL_STYLE)
        self.input_box.returnPressed.connect(self.send_message)
        # Typing counts as activity, so Bob won't shrink mid-sentence.
        self.input_box.textEdited.connect(self.reset_idle_timer)
        outer.addWidget(self.input_box)

        self.worker = None

        # --- System tray icon ---
        # Gives Bob a permanent home in the tray so he can never get lost,
        # and is how you bring him back after hiding. Uses a mood image as
        # the icon (falls back to no image if none found).
        self.tray = QSystemTrayIcon(self)
        tray_img = pick_mood_image("neutral")
        if tray_img:
            self.tray.setIcon(QIcon(tray_img))
        self.tray.setToolTip("Bob")

        tray_menu = QMenu()
        show_action = QAction("Show Bob", self)
        show_action.triggered.connect(self.show_bob)
        hide_action = QAction("Hide Bob", self)
        hide_action.triggered.connect(self.hide)
        quit_action = QAction("Quit", self)
        quit_action.triggered.connect(self.close)
        tray_menu.addAction(show_action)
        tray_menu.addAction(hide_action)
        tray_menu.addSeparator()
        tray_menu.addAction(quit_action)
        self.tray.setContextMenu(tray_menu)

        # Left-click the tray icon also shows Bob.
        self.tray.activated.connect(self.on_tray_activated)
        self.tray.show()

        # --- Idle timer: auto-shrink after IDLE_MINUTES of no activity ---
        # The timer counts down; any activity calls reset_idle_timer() to
        # start it over. If it ever actually fires, we've been idle the whole
        # time, so we shrink. setInterval is in milliseconds.
        self.idle_timer = QTimer(self)
        self.idle_timer.setSingleShot(True)  # fire once, not repeatedly
        self.idle_timer.timeout.connect(self.on_idle)
        if IDLE_MINUTES > 0:
            self.idle_timer.setInterval(IDLE_MINUTES * 60 * 1000)
            self.idle_timer.start()

        # --- Hardware watchdog ---
        # Runs on its own thread; emits a warning string when something's
        # been sustained-high. We route that into Bob reacting (worried face
        # + the warning in his bubble).
        self.watchdog = HardwareWatchdog()
        self.watchdog.warning.connect(self.on_hardware_warning)
        self.watchdog.start()

        # --- Fetch the model list once, in the background ---
        # Done off the main thread so it never freezes the UI. The menu reads
        # the cached result instantly. refresh_models() can re-fetch on demand.
        self.refresh_models()

    def refresh_models(self):
        self.model_worker = ModelListWorker()
        self.model_worker.models_ready.connect(self.on_models_fetched)
        self.model_worker.start()

    def on_models_fetched(self, models):
        self.cached_models = models

    def reset_idle_timer(self):
        # Called on any activity — restarts the countdown from zero.
        if IDLE_MINUTES > 0:
            self.idle_timer.start()

    def on_idle(self):
        # Timer reached zero with no activity — tuck Bob away.
        if not self.is_shrunk:
            self.shrink()

    def on_hardware_warning(self, message):
        # A sustained hardware problem was detected. Bob pops up worried and
        # says something. If he's shrunk, expand so the user actually sees it.
        if self.is_shrunk:
            self.expand()
        self.set_mood_image("worried")
        self.bubble.setText(message)
        self.chat_area.append(f"<b>{self.display_name()}:</b> {message}<br>")
        # A tray notification too, in case Bob's hidden or in the background.
        self.tray.showMessage(self.display_name(), message,
                              QSystemTrayIcon.Warning, 5000)

    def on_tray_activated(self, reason):
        # Trigger is a left-click on the tray icon.
        if reason == QSystemTrayIcon.Trigger:
            self.show_bob()

    def show_bob(self):
        self.show()
        self.raise_()
        self.activateWindow()

    def toggle_mode(self):
        # Flip between bubble view and full-chat view.
        self.full_chat_mode = not self.full_chat_mode
        if self.full_chat_mode:
            self.bubble.hide()
            self.chat_area.show()
            self.toggle_btn.setText("Bubble")
        else:
            self.chat_area.hide()
            self.bubble.show()
            self.toggle_btn.setText("Full chat")
        self.adjustSize()  # let the window resize to fit the new layout

    # --- The ☰ settings popup menu ---
    def open_menu(self):
        menu = QMenu(self)

        # Send to back: drop Bob behind other windows momentarily.
        send_back = QAction("Send to back", self)
        send_back.triggered.connect(self.send_to_back)
        menu.addAction(send_back)

        # Stay on top: a checkable toggle reflecting current state.
        stay_top = QAction("Stay on top", self)
        stay_top.setCheckable(True)
        stay_top.setChecked(self.always_on_top)
        stay_top.triggered.connect(self.toggle_always_on_top)
        menu.addAction(stay_top)

        menu.addSeparator()

        # Personality submenu: lists all personality files; pick to switch.
        personality_menu = menu.addMenu("Personality")
        names = list_personalities()
        if names:
            for name in names:
                act = QAction(name.replace(".txt", ""), self)
                act.setCheckable(True)
                act.setChecked(name == self.current_personality)
                # default arg captures the current name in the loop correctly.
                act.triggered.connect(lambda checked, n=name: self.switch_personality(n))
                personality_menu.addAction(act)
        else:
            no_p = QAction("(no personality files found)", self)
            no_p.setEnabled(False)
            personality_menu.addAction(no_p)

        # Model submenu: reads the CACHED list (filled in the background at
        # startup) so the menu opens instantly — no network call here.
        model_menu = menu.addMenu("Model")
        models = self.cached_models
        if models:
            for m in models:
                act = QAction(m, self)
                act.setCheckable(True)
                act.setChecked(m == self.current_model)
                act.triggered.connect(lambda checked, mm=m: self.switch_model(mm))
                model_menu.addAction(act)
        else:
            none_act = QAction("(no models cached yet)", self)
            none_act.setEnabled(False)
            model_menu.addAction(none_act)
        model_menu.addSeparator()
        refresh_act = QAction("Refresh list", self)
        refresh_act.triggered.connect(self.refresh_models)
        model_menu.addAction(refresh_act)

        menu.addSeparator()

        # Hide: tuck Bob away; bring him back via the tray icon.
        hide_action = QAction("Hide (use tray to return)", self)
        hide_action.triggered.connect(self.hide)
        menu.addAction(hide_action)

        # Show the menu just below the ☰ button.
        menu.exec(self.menu_btn.mapToGlobal(self.menu_btn.rect().bottomLeft()))

    def send_to_back(self):
        # Lower Bob behind sibling windows. With always-on-top set, this is
        # only momentary, so we briefly drop the flag to make it stick.
        self.lower()
        if self.always_on_top:
            self.setWindowFlag(Qt.WindowStaysOnTopHint, False)
            self.show()
            self.lower()
            self.always_on_top = False

    def toggle_always_on_top(self):
        self.always_on_top = not self.always_on_top
        self.setWindowFlag(Qt.WindowStaysOnTopHint, self.always_on_top)
        self.show()   # re-show is required after changing window flags

    def switch_personality(self, name):
        # Swap Bob's character but KEEP the conversation. Because personality
        # lives in exactly one place — messages[0], the system message — we
        # just replace that one element. Everything after it (the chat) stays.
        self.current_personality = name
        new_personality = load_personality(name)
        self.messages[0] = {"role": "system", "content": new_personality}
        # A little in-character notice so the switch is visible.
        nice_name = self.display_name()
        self.bubble.setText(f"(Switched to: {nice_name})")
        self.chat_area.append(f"<i>— switched personality to {nice_name} —</i><br>")
        # Update name-dependent UI labels so they match the new character.
        self.input_box.setPlaceholderText(f"Talk to {nice_name}...")

    def display_name(self):
        # The current character's name, derived from the personality filename
        # (e.g. "grumpy.txt" -> "Grumpy"). Used for all UI labels so they
        # match whoever's active, instead of being hardcoded to "Bob".
        if not self.current_personality:
            return "Bob"
        return self.current_personality.replace(".txt", "").capitalize()

    def switch_model(self, model_name):
        # Change which Ollama model Bob uses. The conversation continues — the
        # new model just picks up from here. Personality and history are
        # unchanged; only the "brain" doing the thinking swaps.
        self.current_model = model_name
        self.chat_area.append(f"<i>— switched model to {model_name} —</i><br>")
        self.bubble.setText(f"(Now running on: {model_name})")

    # --- Shrink to just Bob's face ---
    # Hide everything except the mood image, and shrink the window down.
    # Clicking Bob's face (handled in mousePressEvent) brings it all back.
    def shrink(self):
        self.is_shrunk = True
        for w in self.top_bar_widgets:
            w.hide()
        self.bubble.hide()
        self.chat_area.hide()
        self.status_label.hide()
        self.input_box.hide()
        # Only Bob's face remains visible.
        self.resize(150, 150)
        self.adjustSize()

    def expand(self):
        self.is_shrunk = False
        self.reset_idle_timer()   # expanding counts as activity
        for w in self.top_bar_widgets:
            w.show()
        self.status_label.show()
        self.input_box.show()
        # Restore whichever main view was active (bubble or full chat).
        if self.full_chat_mode:
            self.chat_area.show()
        else:
            self.bubble.show()
        self.resize(460, 360)
        self.adjustSize()

    def set_mood_image(self, mood):
        path = pick_mood_image(mood)
        if path:
            pixmap = QPixmap(path).scaledToHeight(150, Qt.SmoothTransformation)
            self.mood_label.setPixmap(pixmap)
        else:
            self.mood_label.setText(f"({mood})")

    # --- Dragging (only when grabbing non-interactive areas) ---
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            # If shrunk, a click expands Bob back to full size.
            if self.is_shrunk:
                self.expand()
                return
            self._drag_offset = event.globalPosition().toPoint() - self.pos()

    def mouseMoveEvent(self, event):
        if self._drag_offset is not None and event.buttons() & Qt.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_offset)

    def mouseReleaseEvent(self, event):
        self._drag_offset = None

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.close()

    def closeEvent(self, event):
        # Stop the background watchdog thread and remove the tray icon
        # so nothing lingers after quitting.
        self.watchdog.stop()
        self.watchdog.wait(2000)   # give it up to 2s to finish cleanly
        self.tray.hide()
        event.accept()

    def send_message(self):
        user_text = self.input_box.text().strip()
        if not user_text:
            return
        self.reset_idle_timer()   # activity — restart the idle countdown
        # Always record into the full-chat log.
        self.chat_area.append(f"<b>You:</b> {user_text}")
        self.input_box.clear()

        # --- Live-stats injection ---
        # If the message looks like it's asking about hardware, quietly slip
        # the REAL current numbers into the context as a system note. Bob then
        # answers from real data instead of hallucinating (no more fake clocks).
        stats_note = self.maybe_build_stats_note(user_text)
        if stats_note:
            self.messages.append({"role": "system", "content": stats_note})

        self.messages.append({"role": "user", "content": user_text})
        self.input_box.setEnabled(False)
        self.status_label.setText(f"{self.display_name()} is thinking...")

        self.worker = OllamaWorker(self.messages, self.current_model)
        self.worker.reply_ready.connect(self.show_reply)
        self.worker.start()

    def maybe_build_stats_note(self, text):
        # Returns a context note with live readings IF the message seems to be
        # about hardware, else None. Keyword-based: simple and reliable for a
        # small model (proper "function calling" is a bigger, later upgrade).
        lowered = text.lower()
        keywords = ("cpu", "processor", "ram", "memory", "disk", "drive",
                    "storage", "hardware", "usage", "performance",
                    "gpu", "graphics", "vram", "video memory", "video card",
                    "temp", "temperature", "hot", "heat", "overheat", "thermal",
                    "how's my pc", "hows my pc", "my computer")
        if not any(k in lowered for k in keywords):
            return None

        cpu = self.watchdog.current_cpu_average()
        ram = self.watchdog.current_ram_average()
        disk = self.watchdog.current_disk_usage()
        note = (
            "LIVE SYSTEM READINGS (use these real numbers AND their plain-language "
            "meaning to answer accurately — don't second-guess the labels): "
            f"CPU is {cpu:.0f}% ({describe_usage(cpu)}); "
            f"RAM is {ram:.0f}% ({describe_usage(ram)}); "
            f"main disk is {disk:.0f}% full ({describe_usage(disk)})."
        )

        # GPU only if there's actually one available.
        gpu = self.watchdog.current_gpu_average()
        vram = self.watchdog.current_vram_average()
        gpu_temp = self.watchdog.current_gpu_temp_average()
        if gpu is not None:
            note += (
                f" GPU utilization is {gpu:.0f}% ({describe_usage(gpu)}); "
                f"GPU video memory is {vram:.0f}% used ({describe_usage(vram)}); "
                f"GPU temperature is {gpu_temp:.0f}°C ({describe_gpu_temp(gpu_temp)})."
            )
            note += (" Note: CPU temperature is NOT available — if asked about "
                     "CPU temp specifically, say you can only read GPU temp for now.")
        else:
            note += " No NVIDIA GPU readings are available on this system."

        note += " These are real, current readings from this PC."
        return note

    def show_reply(self, reply):
        self.messages.append({"role": "assistant", "content": reply})
        clean, mood = parse_mood(reply)
        self.set_mood_image(mood)
        # Bubble shows just this latest reply; chat log appends to history.
        self.bubble.setText(clean)
        self.chat_area.append(f"<b>{self.display_name()}:</b> {clean}<br>")
        self.status_label.setText("")
        self.input_box.setEnabled(True)
        self.input_box.setFocus()


if __name__ == "__main__":
    app = QApplication([])
    window = CompanionWindow()
    window.show()
    app.exec()
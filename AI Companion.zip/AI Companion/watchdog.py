"""
watchdog.py — background hardware monitor for the AI companion.

Runs on its own thread, samples CPU / RAM / disk once a second, keeps a
rolling average of the last N readings, and emits a signal when something
stays over a threshold (sustained, not a momentary spike). A cooldown stops
it from repeating the same warning every second.

GPU and temperature monitoring are deliberately NOT here yet — those are
planned follow-ups (GPU: NVIDIA first via pynvml; temps: LibreHardwareMonitor).
"""

import time
from collections import deque

import psutil
from PySide6.QtCore import QThread, Signal

# --- Optional NVIDIA GPU support ---
# pynvml (from the 'nvidia-ml-py' package) reads NVIDIA GPU stats without
# admin rights. We import it defensively: if it's missing or there's no
# NVIDIA GPU, GPU monitoring is silently skipped and everything else works.
# AMD/Intel support can be added later behind the same GPU_AVAILABLE flag.
try:
    import pynvml
    pynvml.nvmlInit()
    GPU_AVAILABLE = pynvml.nvmlDeviceGetCount() > 0
except Exception:
    GPU_AVAILABLE = False


# --- Tunable settings (later these can be exposed in the settings menu) ---
SAMPLE_SECONDS = 1        # how often to take a reading
WINDOW_SIZE = 10          # how many readings to average over (10s window)
COOLDOWN_SECONDS = 60     # min seconds between repeats of the SAME warning

CPU_THRESHOLD = 90        # warn if avg CPU% stays above this
RAM_THRESHOLD = 90        # warn if avg RAM% stays above this
DISK_THRESHOLD = 95       # warn if disk usage% is above this
VRAM_THRESHOLD = 95       # warn if avg GPU memory% stays above this
GPU_TEMP_THRESHOLD = 85   # warn if avg GPU temp (°C) stays above this
# 85°C is a reasonable "getting hot" line for most GPUs; many throttle around
# 83–88°C. Adjustable later in settings.
# Note: we deliberately DON'T warn on high GPU *utilization* — a GPU pegged
# at 100% is normal/expected during gaming or rendering. We only watch VRAM,
# since running out of video memory actually causes problems.


# --- INTERPRETATION HELPERS -------------------------------------------------
# Turn raw numbers into plain-language labels so Bob can speak about hardware
# with real understanding instead of guessing. Computed in code (reliable),
# then handed to the model alongside the numbers.

def describe_usage(percent):
    # For CPU / RAM / GPU utilization and VRAM — a "how busy" scale.
    if percent < 10:
        return "basically idle — barely being used"
    elif percent < 30:
        return "light load — plenty of headroom"
    elif percent < 60:
        return "moderate load — working but comfortable"
    elif percent < 85:
        return "heavy load — getting busy"
    else:
        return "very high — close to maxed out"


def describe_gpu_temp(celsius):
    # GPU temperature scale. Modern GPUs idle 30–50°C, game 60–80°C,
    # and start to throttle around 83–88°C.
    if celsius < 50:
        return "cool — essentially idle"
    elif celsius < 70:
        return "warm — normal under light load"
    elif celsius < 83:
        return "hot but fine — typical gaming range"
    else:
        return "running too hot — may start throttling"


class HardwareWatchdog(QThread):
    # Emitted when a sustained problem is detected. Carries a human-readable
    # warning string that the GUI can show in Bob's bubble.
    warning = Signal(str)

    def __init__(self):
        super().__init__()
        self._running = True

        # Rolling windows of recent readings. deque(maxlen=N) automatically
        # drops the oldest reading when a new one is added — perfect for a
        # fixed-size rolling average with zero bookkeeping.
        self.cpu_readings = deque(maxlen=WINDOW_SIZE)
        self.ram_readings = deque(maxlen=WINDOW_SIZE)
        self.gpu_readings = deque(maxlen=WINDOW_SIZE)    # GPU utilization %
        self.vram_readings = deque(maxlen=WINDOW_SIZE)   # GPU memory %
        self.gpu_temp_readings = deque(maxlen=WINDOW_SIZE)  # GPU temp °C

        # Grab a handle to the first GPU once, if one's available.
        self._gpu_handle = None
        if GPU_AVAILABLE:
            try:
                self._gpu_handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            except Exception:
                self._gpu_handle = None

        # Track the last time we warned about each thing, for the cooldown.
        self._last_warned = {"cpu": 0.0, "ram": 0.0, "disk": 0.0,
                             "vram": 0.0, "gpu_temp": 0.0}

    def run(self):
        while self._running:
            # --- Take readings ---
            # cpu_percent with interval=None returns usage since the last
            # call, which is what we want for a once-a-second sampler.
            cpu = psutil.cpu_percent(interval=None)
            ram = psutil.virtual_memory().percent

            self.cpu_readings.append(cpu)
            self.ram_readings.append(ram)

            # GPU readings, only if a handle is available.
            if self._gpu_handle is not None:
                try:
                    util = pynvml.nvmlDeviceGetUtilizationRates(self._gpu_handle)
                    mem = pynvml.nvmlDeviceGetMemoryInfo(self._gpu_handle)
                    temp = pynvml.nvmlDeviceGetTemperature(
                        self._gpu_handle, pynvml.NVML_TEMPERATURE_GPU)
                    self.gpu_readings.append(util.gpu)            # % busy
                    self.vram_readings.append(mem.used / mem.total * 100)
                    self.gpu_temp_readings.append(temp)          # °C
                except Exception:
                    pass  # transient read failure — just skip this cycle

            # --- Check sustained averages against thresholds ---
            self._check_cpu()
            self._check_ram()
            self._check_disk()
            self._check_vram()
            self._check_gpu_temp()

            time.sleep(SAMPLE_SECONDS)

    def _average(self, readings):
        if not readings:
            return 0.0
        return sum(readings) / len(readings)

    def _can_warn(self, key):
        # True if enough time has passed since we last warned about `key`.
        return (time.time() - self._last_warned[key]) >= COOLDOWN_SECONDS

    def _mark_warned(self, key):
        self._last_warned[key] = time.time()

    def _check_cpu(self):
        # Only judge once the window is full, so early seconds don't false-alarm.
        if len(self.cpu_readings) < WINDOW_SIZE:
            return
        avg = self._average(self.cpu_readings)
        if avg > CPU_THRESHOLD and self._can_warn("cpu"):
            self._mark_warned("cpu")
            self.warning.emit(
                f"Your CPU's been running at about {avg:.0f}% for a while — "
                f"something might be working it hard."
            )

    def _check_ram(self):
        if len(self.ram_readings) < WINDOW_SIZE:
            return
        avg = self._average(self.ram_readings)
        if avg > RAM_THRESHOLD and self._can_warn("ram"):
            self._mark_warned("ram")
            self.warning.emit(
                f"Your memory's nearly full — sitting around {avg:.0f}% used. "
                f"You might want to close a few things."
            )

    def _check_disk(self):
        # Disk doesn't need averaging — it changes slowly. Just read C:\.
        usage = psutil.disk_usage("C:\\").percent
        if usage > DISK_THRESHOLD and self._can_warn("disk"):
            self._mark_warned("disk")
            self.warning.emit(
                f"Your main drive is {usage:.0f}% full — running low on space."
            )

    def _check_vram(self):
        if len(self.vram_readings) < WINDOW_SIZE:
            return
        avg = self._average(self.vram_readings)
        if avg > VRAM_THRESHOLD and self._can_warn("vram"):
            self._mark_warned("vram")
            self.warning.emit(
                f"Your GPU's video memory is nearly maxed out — around "
                f"{avg:.0f}% used. Heavy graphics load right now."
            )

    def _check_gpu_temp(self):
        if len(self.gpu_temp_readings) < WINDOW_SIZE:
            return
        avg = self._average(self.gpu_temp_readings)
        if avg > GPU_TEMP_THRESHOLD and self._can_warn("gpu_temp"):
            self._mark_warned("gpu_temp")
            self.warning.emit(
                f"Your GPU's running hot — averaging about {avg:.0f}°C. "
                f"Might be worth checking your airflow or easing off the load."
            )

    # --- Public helpers so the GUI can ask for current numbers on demand ---
    # (These power the future "hey Bob, what's my CPU been doing?" feature.)
    def current_cpu_average(self):
        return self._average(self.cpu_readings)

    def current_ram_average(self):
        return self._average(self.ram_readings)

    def current_disk_usage(self):
        return psutil.disk_usage("C:\\").percent

    def current_gpu_average(self):
        # Returns None if there's no GPU, so callers can tell "0%" apart
        # from "no GPU available".
        if self._gpu_handle is None or not self.gpu_readings:
            return None
        return self._average(self.gpu_readings)

    def current_vram_average(self):
        if self._gpu_handle is None or not self.vram_readings:
            return None
        return self._average(self.vram_readings)

    def current_gpu_temp_average(self):
        if self._gpu_handle is None or not self.gpu_temp_readings:
            return None
        return self._average(self.gpu_temp_readings)

    def stop(self):
        self._running = False
        # Clean up NVML if we initialised it.
        if GPU_AVAILABLE:
            try:
                pynvml.nvmlShutdown()
            except Exception:
                pass
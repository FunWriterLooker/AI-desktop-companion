# This script does NOT talk to the AI. It's purely to SHOW you how a
# messages list gets flattened into one role-marked string before the
# model sees it. Run it, read the output, then delete it whenever.

messages = [
    {"role": "system",    "content": "You are Bob, a witty desktop companion."},
    {"role": "user",      "content": "Hey, what's your name?"},
    {"role": "assistant", "content": "Name's Bob. Nice to meet you."},
    {"role": "user",      "content": "What time is it?"},
]

# This is roughly what Ollama does internally: walk the list and wrap
# each message in markers that label WHO is speaking. (Real models use
# their own exact token format, but the IDEA is exactly this.)
flattened = ""
for m in messages:
    role = m["role"]
    content = m["content"]
    flattened += f"<|{role}|>\n{content}\n"

# The trailing open marker is the model's cue: "you are the assistant,
# now predict what comes next."
flattened += "<|assistant|>\n"

print("=" * 50)
print("THIS is what the model actually 'sees':")
print("=" * 50)
print(flattened)
print("=" * 50)
print("Notice the empty <|assistant|> at the very bottom.")
print("That's the model's cue to predict Bob's next reply.")
# Bob — Project Roadmap & Notes

A local, privacy-focused AI desktop companion. Runs fully offline, no data
leaves the PC. Personality-driven, mood-reactive, with hardware monitoring.

---

## ✅ Done

**Core goals (all complete):**
- Local engine with real answers, fully offline (via Ollama)
- "No data leaves the PC" — verified working with wifi off
- Editable personality via text files
- Frameless, always-on-top, floating Clippy-style window
- AI engine wired into the GUI
- It works!

**Bonuses (both complete):**
- Mood-reactive images (Bob's face changes with his emotional tone)
- Hardware watchdog with alerts

**Polish & extras shipped:**
- Transparent, draggable window; bubble / full-chat toggle
- Shrink-to-icon + click-to-expand
- Idle-timer auto-shrink
- ☰ settings menu + system tray (send-to-back, stay-on-top, hide/summon)
- Hardware watchdog: CPU, RAM, disk, GPU usage, VRAM, GPU temp
  - Background warnings (sustained-high, with cooldown so it doesn't nag)
  - "Ask Bob" live stats ("how's my CPU?") via keyword injection
  - Plain-language interpretation labels (so Bob knows 39°C = cool, not hot)
- Personality switcher (keeps the chat, auto-adds mood rules to any file)
- Model picker (lists installed Ollama models; cached so the menu stays fast)
- Robust Ollama error handling (surfaces real errors, not cryptic ones)

---

## 📋 To Do

**Easy / no-code:**
- Transparent-background mood art (so Bob floats without the white box)

**Small features:**
- Persist settings between sessions (remember chosen model, personality,
  idle time) — currently resets to defaults on restart
- Optional polish: three-tier model labels (Light/Balanced/Heavy),
  AMD/Intel GPU support (flag already in place), auto-minimize toggle in
  settings, idle-time as a user setting

**Big features (own dedicated sessions):**
- Saved/selectable chats + memory (like ChatGPT/Claude conversation history).
  The "clear the decks" feature — needs persistent storage, listing/loading,
  switching the active conversation. Closely tied to giving Bob memory.
- Backend generalization (see below) — make Bob work with any model backend,
  not just Ollama.

**Shipping:**
- `.exe` packaging (with PySide6 LGPL attribution — include Qt license text,
  dynamic linking; PyInstaller default mode handles this)

---

## 🎨 Phase 3 — Fun Capabilities (someday, after core is polished/shipped)

These are "Bob gains a new sense/skill" features. Each is a SEPARATE optional
pipeline bolted onto the side — NOT a change to the core text brain. Text and
images/audio are different KINDS of model, so they're additions, not swaps.
Think "new tool for Bob," same pattern as the hardware-stats tool use.

Key shared traits:
- These models are HEAVIER than text (esp. image gen — lots of VRAM, several
  seconds per image). So each is OPTIONAL — works if the hardware supports it,
  gracefully absent otherwise (same logic as GPU temps).
- The cleanest ones expose an HTTP API, so Bob talks to them exactly like it
  talks to Ollama — reusing the whole "talk to a local server" architecture.
- All stay local = privacy promise intact.

Ideas, roughly by "companion value":
- **Text-to-speech** — Bob talks back in a voice. Probably the biggest vibe
  upgrade for a desktop companion. (HF has good TTS models.)
- **Text-to-image** — Bob can draw ("draw me a cat" → image tool → show it).
  Most novel use: GENERATE mood faces on the fly instead of static PNGs.
  Local tools with APIs: ComfyUI, Automatic1111 (slot into the HTTP pattern).
- **Speech-to-text** — talk to Bob out loud instead of typing.
- **Vision** — show Bob an image and he can "see"/describe it (small vision
  model).

Framing: this is the "phase 3 delight" layer. Core first, packaging second,
THEN this is where Bob gets genuinely magical (draws, speaks, listens).

---

## 🔌 Backend Generalization Plan (for later)

**Vision:** Bob as a lightweight, privacy-focused *frontend* that works with
ANY model backend — Ollama, LM Studio, llama.cpp server, a user's own trained
model behind an API. Bob stays the friendly companion layer; the engine stays
external and swappable. (This is "Goal A" — Bob doesn't run models itself,
it just doesn't care *what* runs them. NOT "Goal B" where Bob loads models
directly — that's heavier and not actually needed for the vision.)

**The one principle:** All "how we talk to a model" logic stays sealed inside
a single class (currently `OllamaWorker`). Nothing backend-specific leaks into
the GUI, watchdog, etc. The rest of Bob only ever says "give me a reply to
these messages."

**Steps (when there's a real reason to do it):**
1. Target the **OpenAI-compatible API** — the near-universal standard almost
   every local tool can speak (Ollama included, in its OpenAI mode). One
   format unlocks "works with everything."
2. Generalize the one class: takes an endpoint URL, an API format/type, and
   a model name. The Ollama version becomes just one config of this, not a
   special case.
3. Add backend settings the user can change: server address/URL (default:
   localhost:11434), optional API-type picker.
4. Test against a real second backend (LM Studio is easy). THIS is when to
   build it — having two concrete backends shows what actually needs to flex.
   Abstracting before that = guessing in the dark.
5. Privacy/safety layer: signal WHERE the model runs — reassure when local,
   warn if pointed at a remote URL. Keeps the privacy promise honest once
   backends are configurable. Design this WITH the backend work.

**When to do it:** when there's a concrete reason to leave single-Ollama —
either you personally want a different tool, or you're prepping for wider
distribution. Until then, it stays on paper. The only thing to do NOW is keep
that one class clean (already being done). No corner has been painted.

---

## 🛠️ Key learnings / patterns (so they're not lost)

- **Never block the main thread.** Network/disk/slow work goes on a QThread
  with a Signal to hand results back, or the whole UI freezes. (Hit this with
  the Ollama call AND the model-list fetch.)
- **Do judgment in code, let the model phrase it.** Small models are unreliable
  at judging (is 39°C hot? is "eager" a valid mood?). Compute the answer in
  code, hand the model the conclusion. (Mood synonyms, temp labels, honest
  "can't read CPU temp" note.)
- **Cache data that rarely changes**, with a manual refresh, instead of
  re-fetching every access. (Model list.)
- **Handle the empty/failure case explicitly** for anything that could be
  missing. (Empty mood folders, no GPU, Ollama offline, error responses.)
- **Build foundations first; features fall out cheap.** shrink → auto-shrink,
  watchdog data → "ask Bob" feature, one personality slot → easy switching.
- **When an error is vague, surface the raw data underneath before guessing.**
  ("'message'" KeyError hid "llama-server binary not found" — one debug print
  cracked it.)
- **Don't hardcode values that gain variety later.** "Bob" was fine as the only
  name; switchable personalities made every hardcoded "Bob" stale. Derive from
  one source of truth instead.
- **PySide6 (LGPL) over PyQt6 (GPL/paid)** for free distribution.

---

## 🗂️ Project structure

```
AI Companion/
├── companion_gui.py     # main app: window, chat, menu, all features
├── watchdog.py          # hardware monitoring (its own module)
├── personalities/       # one .txt per character (just character text;
│   ├── bob.txt          #   mood rules auto-added in code)
│   └── grumpy.txt
└── moods/               # mood images, one subfolder per mood
    ├── happy/
    ├── neutral/
    ├── sad/
    └── worried/
```

Models live in Ollama (`~/.ollama/models`), NOT in this folder — Bob just
reflects whatever Ollama has installed.
